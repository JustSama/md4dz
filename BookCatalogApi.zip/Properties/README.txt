Launch settings are included in launchSettings.json.
