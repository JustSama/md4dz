using AutoMapper;
using BookCatalogApi.DTOs;
using BookCatalogApi.Models;
using BookCatalogApi.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace BookCatalogApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BooksController : ControllerBase
{
    private readonly IBookRepository _repository;
    private readonly IMapper _mapper;

    public BooksController(IBookRepository repository, IMapper mapper)
    {
        _repository = repository;
        _mapper = mapper;
    }

    [HttpGet]
    public async Task<ActionResult<ReturnResult<List<BookDto>>>> GetAll()
    {
        var books = await _repository.GetAllAsync();
        var result = _mapper.Map<List<BookDto>>(books);

        return Ok(ReturnResult<List<BookDto>>.Ok(
            result,
            "Books retrieved successfully."));
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ReturnResult<BookDto>>> GetById(int id)
    {
        var book = await _repository.GetByIdAsync(id);

        if (book == null)
        {
            return NotFound(ReturnResult<BookDto>.Fail(
                $"Book with id {id} was not found."));
        }

        var result = _mapper.Map<BookDto>(book);

        return Ok(ReturnResult<BookDto>.Ok(
            result,
            "Book retrieved successfully."));
    }

    [HttpGet("search")]
    public async Task<ActionResult<ReturnResult<List<BookDto>>>> SearchByAuthor(
        [FromQuery] string author)
    {
        if (string.IsNullOrWhiteSpace(author))
        {
            return BadRequest(ReturnResult<List<BookDto>>.Fail(
                "Author parameter is required."));
        }

        var books = await _repository.SearchByAuthorAsync(author);
        var result = _mapper.Map<List<BookDto>>(books);

        return Ok(ReturnResult<List<BookDto>>.Ok(
            result,
            $"Search completed for author: {author}."));
    }

    [HttpPost]
    public async Task<ActionResult<ReturnResult<BookDto>>> Create(
        [FromBody] CreateBookDto dto)
    {
        var book = _mapper.Map<Book>(dto);

        var createdBook = await _repository.AddAsync(book);
        var result = _mapper.Map<BookDto>(createdBook);

        return CreatedAtAction(
            nameof(GetById),
            new { id = result.Id },
            ReturnResult<BookDto>.Ok(
                result,
                "Book created successfully."));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<ReturnResult<BookDto>>> Update(
        int id,
        [FromBody] UpdateBookDto dto)
    {
        var existingBook = await _repository.GetByIdAsync(id);

        if (existingBook == null)
        {
            return NotFound(ReturnResult<BookDto>.Fail(
                $"Book with id {id} was not found."));
        }

        var book = _mapper.Map<Book>(dto);
        book.Id = id;

        var updated = await _repository.UpdateAsync(book);

        if (!updated)
        {
            return NotFound(ReturnResult<BookDto>.Fail(
                $"Book with id {id} was not found."));
        }

        var updatedBook = await _repository.GetByIdAsync(id);
        var result = _mapper.Map<BookDto>(updatedBook);

        return Ok(ReturnResult<BookDto>.Ok(
            result!,
            "Book updated successfully."));
    }

    [HttpDelete("{id:int}")]
    public async Task<ActionResult<ReturnResult<object>>> Delete(int id)
    {
        var deleted = await _repository.DeleteAsync(id);

        if (!deleted)
        {
            return NotFound(ReturnResult<object>.Fail(
                $"Book with id {id} was not found."));
        }

        return Ok(ReturnResult<object>.Ok(
            new { id },
            "Book deleted successfully."));
    }
}
